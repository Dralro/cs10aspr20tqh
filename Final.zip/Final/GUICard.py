import csv
from tkinter import *
import operator

sr = list(csv.DictReader(open("search.csv", 'r'), delimiter=","))

top = Tk()
top.geometry('380x400')
top.title("Magic: The Gathering Card Search")

results = []
global rar
rar = StringVar()
rar.set("C")

color_l = ["W", "U", "B", "R", "G", "C"]

global tr
tr = Listbox(top, width = 30, height = 9, bg = "white")
tr.place(x = 10, y = 250)

def Search():
    
    tr.delete(0, END)
    
    if not (c.get() >= 5):
        results = [i for i in sr if color_l[c.get()] in i['mana_cost']]
    else:
        results = [i for i in sr if all(["W" not in i['mana_cost'], "U" not in i["mana_cost"], "B" not in i["mana_cost"], "R" not in i["mana_cost"], "G" not in i["mana_cost"]])]
    if (rar.get() != "All"):    
        results = [i for i in results if all ([i['rarity'] == rar.get(), t.get().lower() in i['type_line'].lower(), op_list[tkvar.get()](float(i['cmc']), cd.get())])]
    else:
        results = [i for i in results if all ([t.get().lower() in i['type_line'].lower(), op_list[tkvar.get()](float(i['cmc']), cd.get())])]
    
    for i in results:
        tr.insert(END, i['name'])
    
    results.clear()
    
    return 0
    
c = IntVar()

Radiobutton(top, text ="White", variable = c, fg = "Black", value = 0).grid(row = 0, column = 0, sticky = W)
Radiobutton(top, text ="Blue", variable = c, fg = "Blue", value = 1).grid(row = 0, column = 1,  sticky = W)
Radiobutton(top, text ="Black", variable = c, fg = "Black", value = 2).grid(row = 0, column = 2, sticky = W)
Radiobutton(top, text ="Red", variable = c, fg = "Red", value = 3).grid(row = 1, column = 0, sticky = W)
Radiobutton(top, text ="Green", variable = c, fg = "Green", value = 4).grid(row = 1, column = 1, sticky = W)
Radiobutton(top, text ="Colorless", variable = c, fg = "Gray", value = 5).grid(row = 1, column = 2, sticky = W)

Label(top, text="Rarity: ").place(x = 0, y = 50)

Radiobutton(top, text = "C", variable = rar, value = "C").place(x = 120, y = 50)
Radiobutton(top, text = "U", variable = rar, value = "U").place(x = 150, y = 50)
Radiobutton(top, text = "R", variable = rar, value = "R").place(x = 180, y = 50)
Radiobutton(top, text = "M", variable = rar, value = "M").place(x = 210, y = 50)
Radiobutton(top, text = "None", variable = rar, value = "All").place(x = 250, y = 50)

Label(top, text="Type: ").place(x = 0, y = 100 )
Label(top, text="Converted Mana Cost: ").place(x = 0, y = 150)

tkvar = StringVar(top)

op_list = { '<': operator.lt, '=': operator.eq, '>': operator.gt, '<=': operator.le, '>=': operator.ge,'!=': operator.ne}

tkvar.set('>=')

popupMenu = OptionMenu(top, tkvar, *op_list)
popupMenu.place(x = 125, y = 150)

def change_dropdown(*args):
    print( tkvar.get() )

# link function to change dropdown
tkvar.trace('w', change_dropdown)

cd = IntVar(top, value = 0)
t = StringVar(top, value = "")

Type = Entry(top, textvariable = t).place(x = 100, y = 100)
CMC = Entry(top, textvariable = cd).place(x = 200, y = 150)
Button(top, text='Show', command = Search).place(x = 100, y = 200)

top.mainloop()